package com.example.soapwebflux.client;

import com.example.soapwebflux.model.SoapRequest;
import com.example.soapwebflux.model.SoapResponse;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.Unmarshaller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.StringReader;
import java.io.StringWriter;

@Service
public class SoapClient {

    @Autowired
    private WebClient webClient;

    private final JAXBContext jaxbContext;

    public SoapClient() throws JAXBException {
        // Initialize JAXBContext with the model classes
        this.jaxbContext = JAXBContext.newInstance(SoapRequest.class, SoapResponse.class);
    }

    // Marshalling: Convert Java object to XML String
    private String marshal(SoapRequest request) throws JAXBException {
        Marshaller marshaller = jaxbContext.createMarshaller();
        StringWriter writer = new StringWriter();
        marshaller.marshal(request, writer);
        return writer.toString();
    }

    // Unmarshalling: Convert XML String to Java object
    private SoapResponse unmarshal(String xml) throws JAXBException {
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        return (SoapResponse) unmarshaller.unmarshal(new StringReader(xml));
    }

    public Mono<SoapResponse> callSoapService(SoapRequest request) {
        try {
            // Marshal the request object to XML
            String xmlRequest = marshal(request);

            // Make the SOAP request
            return webClient.post()
                    .uri("https://example.com/soap-endpoint") // Replace with your SOAP endpoint
                    .header("Content-Type", "text/xml")
                    .bodyValue(xmlRequest)
                    .retrieve()
                    .bodyToMono(String.class)
                    .map(xmlResponse -> {
                        // Unmarshal the XML response to Java object
                        try {
                            return unmarshal(xmlResponse);
                        } catch (JAXBException e) {
                            throw new RuntimeException("Error unmarshalling SOAP response", e);
                        }
                    });

        } catch (JAXBException e) {
            return Mono.error(new RuntimeException("Error marshalling SOAP request", e));
        }
    }
}
