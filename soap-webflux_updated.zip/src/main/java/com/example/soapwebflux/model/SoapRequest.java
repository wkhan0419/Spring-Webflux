package com.example.soapwebflux.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SoapRequest")
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapRequest {

    @XmlElement(name = "Parameter")
    private String parameter;

    // Getters and Setters
    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }
}
