package com.example.soapwebflux.model;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "SoapResponse")
@XmlAccessorType(XmlAccessType.FIELD)
public class SoapResponse {

    @XmlElement(name = "Result")
    private String result;

    // Getters and Setters
    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
