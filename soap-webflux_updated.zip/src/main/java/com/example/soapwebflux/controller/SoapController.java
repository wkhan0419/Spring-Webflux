package com.example.soapwebflux.controller;

import com.example.soapwebflux.client.SoapClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@RestController
public class SoapController {

    @Autowired
    private SoapClient soapClient;

    @GetMapping("/soap")
    public Mono<String> getSoapResponse(@RequestParam String requestPayload) {
        return soapClient.callSoapService(requestPayload);
    }
}
