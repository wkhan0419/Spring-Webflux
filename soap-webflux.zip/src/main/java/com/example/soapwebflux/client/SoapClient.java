package com.example.soapwebflux.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Service
public class SoapClient {

    @Autowired
    private WebClient webClient;

    public Mono<String> callSoapService(String soapRequest) {
        return webClient.post()
                .uri("https://example.com/soap-endpoint") // Replace with your SOAP endpoint
                .header("Content-Type", "text/xml")
                .bodyValue(soapRequest)
                .retrieve()
                .bodyToMono(String.class);
    }
}
